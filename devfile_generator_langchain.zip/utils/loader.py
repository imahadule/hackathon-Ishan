from langchain.document_loaders import TextLoader
from langchain.schema import Document
import os

def load_devfile_documents(directory: str):
    docs = []
    for filename in os.listdir(directory):
        if filename.endswith(".yaml") or filename.endswith(".yml"):
            path = os.path.join(directory, filename)
            loader = TextLoader(path)
            docs.extend(loader.load())
    return docs
