from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.chains import LLMChain

def generate_devfile(user_query: str, retrieved_docs: list[str]):
    context = "\n---\n".join(retrieved_docs)
    prompt = ChatPromptTemplate.from_template(
        """You are a Devfile expert. Use the below context to generate a Devfile based on this query:

Query:
{query}

Context:
{context}

Respond with only the Devfile YAML.
"""
    )
    llm = ChatOpenAI(temperature=0.2, model_name="gpt-4")
    chain = LLMChain(llm=llm, prompt=prompt)
    result = chain.run({"query": user_query, "context": context})
    return result.strip()
