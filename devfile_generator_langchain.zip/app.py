import streamlit as st
import os
from dotenv import load_dotenv
from utils.loader import load_devfile_documents
from utils.retriever import create_vectorstore
from utils.generator import generate_devfile

load_dotenv()
st.set_page_config(layout="wide")
st.title("🧠 Devfile Generator (LangChain + RAG + OpenAI)")

uploaded_files = st.file_uploader("Upload sample devfiles", type=["yaml", "yml"], accept_multiple_files=True)

if uploaded_files:
    os.makedirs("devfile_examples", exist_ok=True)
    for file in uploaded_files:
        with open(os.path.join("devfile_examples", file.name), "wb") as f:
            f.write(file.read())
    st.success("✅ Uploaded Devfiles")

    docs = load_devfile_documents("devfile_examples")
    vectorstore = create_vectorstore(docs)
    retriever = vectorstore.as_retriever()

    user_query = st.text_input("💡 What Devfile do you want to generate?")
    if user_query:
        with st.spinner("Generating Devfile..."):
            retrieved = retriever.get_relevant_documents(user_query)
            retrieved_texts = [doc.page_content for doc in retrieved]
            devfile_yaml = generate_devfile(user_query, retrieved_texts)
            st.code(devfile_yaml, language="yaml")
            st.download_button("Download Devfile", data=devfile_yaml, file_name="devfile.yaml", mime="text/yaml")
else:
    st.info("Upload Devfiles to get started.")
