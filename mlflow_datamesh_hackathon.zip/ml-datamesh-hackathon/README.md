# MLflow on Data Mesh Hackathon Project

This project demonstrates how to use MLflow with AutoML on a Data Mesh architecture, with support for Prometheus logging and GitLab CI pipeline triggering.

## Features

- Decentralized data loading (customer and transaction domains)
- AutoML via PyCaret
- MLflow tracking
- Prometheus push for observability
- GitLab CI/CD integration

## Run Locally

```bash
docker-compose up
```
