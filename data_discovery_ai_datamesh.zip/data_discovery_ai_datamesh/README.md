
# AI-Powered Data Discovery on Data Mesh

## Components

### Backend
- Metadata ingestion (`ingest_metadata.py`)
- Embedding + FAISS indexing (`embedding_service.py`)
- RAG pipeline with OpenAI (`rag_pipeline.py`)
- AutoML profiler simulation (`automl_profiler.py`)
- MLflow logging (`mlflow_logger.py`)

### Frontend
- Streamlit app (`frontend/app.py`)

### VS Code Extension
- Ask natural language questions from VS Code (`vscode-extension/extension.js`)

## How to Run

1. Run metadata ingest and embedding scripts:
```bash
python backend/ingest_metadata.py
python backend/embedding_service.py
```

2. Set your OpenAI API key:
```bash
export OPENAI_API_KEY=your_key_here
```

3. Launch Streamlit UI:
```bash
streamlit run frontend/app.py
```

4. VS Code:
- Open the `vscode-extension` folder as an extension project.
- Run using `F5` inside VS Code.
