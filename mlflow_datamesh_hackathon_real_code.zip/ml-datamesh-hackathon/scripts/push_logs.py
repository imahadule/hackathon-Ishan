from prometheus_client import CollectorRegistry, Gauge, push_to_gateway
import json

with open("pycaret_metrics.json") as f:
    metrics = json.load(f)[0]

registry = CollectorRegistry()
for key, value in metrics.items():
    if isinstance(value, (int, float)):
        g = Gauge(f"pycaret_{key.lower()}", f"Metric {key}", registry=registry)
        g.set(value)

push_to_gateway("localhost:9091", job="pycaret_metrics_push", registry=registry)
