import pandas as pd
import mlflow
import mlflow.sklearn
from pycaret.classification import setup, compare_models, pull
import uuid
import os

# Unique run ID
run_id = str(uuid.uuid4())

# Load sample datasets
customers = pd.read_csv("data/customers.csv")
transactions = pd.read_csv("data/transactions.csv")

# Merge and prepare data
data = pd.merge(customers, transactions, on="customer_id", how="inner")
data = data.dropna()
data["target"] = data["target"].astype(str)

# PyCaret setup
s = setup(data=data, target='target', silent=True, session_id=123)
best_model = compare_models()
results = pull()

# Log to MLflow
mlflow.set_experiment("DataMesh_AutoML")
with mlflow.start_run(run_name="AutoML_Run_" + run_id) as run:
    mlflow.log_params({"model": str(best_model.__class__.__name__), "run_id": run_id})
    for col in ["Accuracy", "AUC", "Recall", "Precision"]:
        if col in results.columns:
            mlflow.log_metric(col, results.loc[0, col])
    mlflow.sklearn.log_model(best_model, "model")
    results["model_name"] = str(best_model.__class__.__name__)
    results["run_id"] = run_id
    results["timestamp"] = pd.Timestamp.utcnow().isoformat()
    results.to_json("pycaret_metrics.json", orient="records")
    mlflow.log_artifact("pycaret_metrics.json")
