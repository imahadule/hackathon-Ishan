import requests
import json

with open("pycaret_metrics.json") as f:
    metrics = json.load(f)[0]

GITLAB_PROJECT_ID = 'your_project_id'
GITLAB_TRIGGER_TOKEN = 'your_trigger_token'
GITLAB_REF = 'main'

run_id = metrics.get("run_id", "unknown")
model_name = metrics.get("model_name", "unknown")

data = {
    "token": GITLAB_TRIGGER_TOKEN,
    "ref": GITLAB_REF,
    "variables[RUN_ID]": run_id,
    "variables[MODEL_NAME]": model_name
}

url = f"https://gitlab.com/api/v4/projects/{GITLAB_PROJECT_ID}/trigger/pipeline"
res = requests.post(url, data=data)
print("Pipeline Triggered" if res.status_code == 201 else res.text)
