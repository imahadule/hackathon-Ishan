# MLflow on Data Mesh Hackathon Project

This project demonstrates a full ML pipeline using MLflow and AutoML in a Data Mesh setup.

## Features

- Feature extraction across domains (Customer & Transaction)
- AutoML via PyCaret
- MLflow logging of metrics and models
- Prometheus metrics push
- GitLab pipeline trigger

## Run

```bash
docker-compose up
python scripts/train.py
python scripts/push_logs.py
python scripts/trigger_pipeline.py
```
