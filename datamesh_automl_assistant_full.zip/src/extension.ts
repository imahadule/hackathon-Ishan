import * as vscode from 'vscode';
import * as path from 'path';
import axios from 'axios';
import * as dotenv from 'dotenv';
dotenv.config();
import { getWebviewContent } from './webview';

export function activate(context: vscode.ExtensionContext) {
  context.subscriptions.push(
    vscode.commands.registerCommand('extension.startAutoMLChat', () => {
      const panel = vscode.window.createWebviewPanel(
        'automlChat',
        'AutoML Assistant',
        vscode.ViewColumn.One,
        {
          enableScripts: true
        }
      );

      panel.webview.html = getWebviewContent();

      panel.webview.onDidReceiveMessage(
        async message => {
          if (message.command === 'trainModel') {
            vscode.window.showInformationMessage(`Triggering AutoML on GitLab for ${message.dataset}`);
            try {
              const response = await axios.post(`${process.env.GITLAB_API_URL}/projects/${process.env.GITLAB_PROJECT_ID}/trigger/pipeline`, {
                token: process.env.GITLAB_TRIGGER_TOKEN,
                ref: 'main',
                variables: { DATASET: message.dataset }
              });
              vscode.window.showInformationMessage(`Pipeline triggered: ${response.data.web_url}`);
            } catch (error) {
              vscode.window.showErrorMessage(`GitLab Trigger Error: ${error}`);
            }
          }
        },
        undefined,
        context.subscriptions
      );
    })
  );
}

export function deactivate() {}
