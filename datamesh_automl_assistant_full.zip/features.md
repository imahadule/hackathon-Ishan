// Suggested Features for VS Code Extension

// ✅ Streamlit Dashboard Integration
// - File: streamlit_dashboard.py
// - Run: `streamlit run streamlit_dashboard.py`

// ✅ Model Promotion UI
// - Add dropdown to select model from leaderboard and promote to production

// ✅ GitLab MR Comments
// - On pipeline success, auto-comment evaluation summary in related MR

// ✅ Feature Importance Viewer
// - Add feature importance chart to Streamlit dashboard

// ✅ Auto Scheduler for AutoML
// - Let user schedule AutoML jobs from command palette using GitLab schedules

// ✅ LLM Integration with LangChain or OpenAI
// - Chat to explain model decisions or summaries

// ✅ MLflow UI Embed
// - Show MLflow UI in iframe or new VS Code tab

// ✅ Jupyter Notebook Export
// - Export training steps as a reproducible .ipynb
