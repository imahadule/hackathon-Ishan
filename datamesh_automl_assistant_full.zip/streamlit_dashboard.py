import streamlit as st
import pandas as pd
import os
import h2o
from h2o.frame import H2OFrame
from h2o.automl import H2OAutoML

st.set_page_config(layout="wide")
st.title("📊 AutoML Model Leaderboard")

model_dir = "./models"
leaderboard_file = os.path.join(model_dir, "leaderboard.csv")

if os.path.exists(leaderboard_file):
    df = pd.read_csv(leaderboard_file)
    st.dataframe(df)
    best_model = df.iloc[0]
    st.success(f"Best Model: {best_model['model_id']} - AUC: {best_model['auc']:.4f}")
else:
    st.warning("No leaderboard file found. Run an AutoML training first.")
