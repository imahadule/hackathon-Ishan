import h2o
from h2o.automl import H2OAutoML
import mlflow
import mlflow.h2o
import os
import sys

mlflow.set_tracking_uri(os.getenv("MLFLOW_TRACKING_URI", "http://mlflow:5000"))
mlflow.set_experiment("automl-datamesh")

h2o.init()
dataset_path = sys.argv[1]
data = h2o.import_file(dataset_path)

x = data.columns[:-1]
y = data.columns[-1]

with mlflow.start_run():
    aml = H2OAutoML(max_runtime_secs=300)
    aml.train(x=x, y=y, training_frame=data)

    lb = aml.leaderboard
    print(lb.head(rows=lb.nrows))

    mlflow.log_param("dataset", dataset_path)
    mlflow.log_param("target", y)
    mlflow.log_metric("auc", aml.leader.auc())

    model_path = h2o.save_model(model=aml.leader, path="./models", force=True)
    mlflow.h2o.log_model(aml.leader, artifact_path="model")
    print("Model saved to:", model_path)
