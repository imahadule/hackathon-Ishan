export function getWebviewContent(): string {
  return \`
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AutoML Assistant</title>
  </head>
  <body>
    <h2>🧠 AutoML Chatbot</h2>
    <input id="input" type="text" style="width: 80%;">
    <button onclick="sendCommand()">Send</button>
    <pre id="output"></pre>
    <script>
      const vscode = acquireVsCodeApi();
      function sendCommand() {
        const input = document.getElementById('input').value;
        document.getElementById('output').textContent += `\n> ${input}`;
        vscode.postMessage({ command: 'trainModel', dataset: input });
      }
    </script>
  </body>
  </html>\`;
}
