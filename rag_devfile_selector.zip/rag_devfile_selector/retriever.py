import os
from langchain.document_loaders import TextLoader
from langchain.text_splitter import CharacterTextSplitter
from langchain.vectorstores import FAISS
from langchain.embeddings import OpenAIEmbeddings

def build_vectorstore(data_path="data/examples"):
    docs = []
    for file in os.listdir(data_path):
        if file.endswith(".yaml") or file.endswith(".yml"):
            path = os.path.join(data_path, file)
            loader = TextLoader(path)
            loaded_docs = loader.load()
            for doc in loaded_docs:
                doc.metadata["source"] = path
                docs.append(doc)

    splitter = CharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
    chunks = splitter.split_documents(docs)

    embeddings = OpenAIEmbeddings()
    db = FAISS.from_documents(chunks, embeddings)
    db.save_local("faiss_index")
    return db

def load_vectorstore():
    embeddings = OpenAIEmbeddings()
    return FAISS.load_local("faiss_index", embeddings, allow_dangerous_deserialization=True)

def search_best_match(query: str, similarity_threshold=0.75):
    vectorstore = load_vectorstore()
    retriever = vectorstore.as_retriever(search_kwargs={"k": 1})

    result = retriever.get_relevant_documents(query)
    if not result:
        return None, None

    best = result[0]
    return best.page_content, best.metadata.get("source", "unknown")