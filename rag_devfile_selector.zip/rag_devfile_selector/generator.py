from langchain.chat_models import ChatOpenAI
from langchain.prompts import PromptTemplate

EXAMPLE_YAML = """schemaVersion: 2.1.0
metadata:
  name: nodejs-app
components:
  - name: runtime
    container:
      image: node:18
      memoryLimit: 512Mi
      mountSources: true
commands:
  - id: start
    exec:
      component: runtime
      commandLine: npm start
      workingDir: /projects
      group:
        kind: run
        isDefault: true
"""

SYSTEM_PROMPT = """You are a Devfile.yaml generator. Based on the user request and example formatting,
generate a valid and complete devfile.yaml with matching schema, indentation, and structure.

Example:
{example}

User Request:
{request}

Output only the devfile.yaml content. No explanation or markdown.
"""

def generate_new_devfile(user_request: str):
    llm = ChatOpenAI(temperature=0.2, model="gpt-4")
    prompt = PromptTemplate.from_template(SYSTEM_PROMPT)
    return llm.predict(prompt.format(example=EXAMPLE_YAML, request=user_request))