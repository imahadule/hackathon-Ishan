import os
from retriever import build_vectorstore, search_best_match
from generator import generate_new_devfile

if not os.path.exists("faiss_index"):
    print("🔧 Index not found. Building vector store from examples...")
    build_vectorstore()

query = input("📥 Enter your environment (e.g., Python Flask with Redis):\n")
print("🔍 Searching for closest devfile match...\n")

match_content, source = search_best_match(query)

os.makedirs("output", exist_ok=True)

if match_content:
    print(f"✅ Match found from: {source}")
    with open("output/generated_devfile.yaml", "w") as f:
        f.write(match_content)
    print("📁 Saved to: output/generated_devfile.yaml")
else:
    print("⚠️ No exact match found. Generating new devfile with OpenAI...")
    new_devfile = generate_new_devfile(query)
    with open("output/generated_devfile.yaml", "w") as f:
        f.write(new_devfile)
    print("✨ New devfile generated and saved to: output/generated_devfile.yaml")