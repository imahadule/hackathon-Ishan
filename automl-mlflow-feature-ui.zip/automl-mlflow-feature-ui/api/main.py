
from fastapi import FastAPI, Request
import mlflow.pyfunc
import pandas as pd

app = FastAPI()
model = mlflow.pyfunc.load_model("models:/mesh-model/Production")

@app.post("/predict")
async def predict(request: Request):
    data = await request.json()
    df = pd.DataFrame(data)
    predictions = model.predict(df)
    return {"predictions": predictions.tolist()}
