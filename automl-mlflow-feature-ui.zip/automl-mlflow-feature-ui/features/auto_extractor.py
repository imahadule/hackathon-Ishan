
import pandas as pd

def extract_features(path):
    df = pd.read_csv(path)
    df.fillna(0, inplace=True)
    X = df.drop("target", axis=1)
    y = df["target"]
    return X, y
