
import streamlit as st
import pandas as pd
import requests

st.title("AutoML Mesh Model - Streamlit UI")

uploaded_file = st.file_uploader("Upload your CSV file", type=["csv"])
if uploaded_file:
    df = pd.read_csv(uploaded_file)
    st.write("Uploaded Data Preview:", df.head())

    if st.button("Predict"):
        response = requests.post("http://localhost:8000/predict", json=df.to_dict(orient="records"))
        st.write("Predictions:", response.json())
