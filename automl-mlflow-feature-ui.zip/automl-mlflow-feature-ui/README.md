# AutoML with MLflow, Feature Extraction, and Streamlit UI
This project trains an ML model using AutoML (FLAML), serves it with FastAPI, and provides a UI with Streamlit.