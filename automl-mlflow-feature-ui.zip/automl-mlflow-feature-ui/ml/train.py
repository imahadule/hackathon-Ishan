
import mlflow
import mlflow.sklearn
from flaml import AutoML
from features.auto_extractor import extract_features
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

X, y = extract_features("data_mesh/domain1.csv")
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

mlflow.set_experiment("AutoML_Mesh_Comparison")

with mlflow.start_run(run_name="FLAML AutoML"):
    automl = AutoML()
    automl_settings = {
        "time_budget": 30,
        "metric": 'accuracy',
        "task": 'classification',
        "log_file_name": "flaml.log",
    }

    automl.fit(X_train=X_train, y_train=y_train, **automl_settings)

    preds = automl.predict(X_test)
    acc = accuracy_score(y_test, preds)

    mlflow.log_param("best_estimator", automl.best_estimator)
    mlflow.log_params(automl.best_config)
    mlflow.log_metric("accuracy", acc)
    mlflow.sklearn.log_model(automl.model, "model")

    print(f"Best model: {automl.best_estimator}, Accuracy: {acc}")
