import pandas as pd
from flaml import AutoML
import mlflow
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from mlflow_helper import log_automl_run
from prometheus_logger import push_metrics_to_prometheus

def train_model():
    df = pd.read_csv("app/data/sample.csv")
    X = df.drop("target", axis=1)
    y = df["target"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    automl = AutoML()
    automl_settings = {
        "time_budget": 60,
        "metric": 'accuracy',
        "task": 'classification',
        "log_file_name": "automl.log",
    }

    with mlflow.start_run() as run:
        automl.fit(X_train=X_train, y_train=y_train, **automl_settings)
        y_pred = automl.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        log_automl_run(run, automl, accuracy)
        push_metrics_to_prometheus(run.info.run_id, accuracy)

    return run.info.run_id

if __name__ == '__main__':
    train_model()
