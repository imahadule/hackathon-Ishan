import streamlit as st
import mlflow
from automl_train import train_model
from langchain_agent import summarize_run

st.title("🔮 AutoML + MLflow Dashboard")

if st.button("🚀 Run AutoML Experiment"):
    run_id = train_model()
    st.success(f"Training complete! Run ID: {run_id}")

    with st.spinner("Fetching results..."):
        client = mlflow.tracking.MlflowClient()
        run = client.get_run(run_id)
        params = run.data.params
        metrics = run.data.metrics

        st.subheader("📊 Metrics")
        st.json(metrics)

        st.subheader("⚙️ Best Parameters")
        st.json(params)

        st.subheader("🧠 Summary (LangChain)")
        summary = summarize_run(params, metrics)
        st.write(summary)
