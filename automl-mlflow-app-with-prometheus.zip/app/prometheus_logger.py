from prometheus_client import Gauge, CollectorRegistry, push_to_gateway

def push_metrics_to_prometheus(run_id: str, accuracy: float):
    registry = CollectorRegistry()
    accuracy_gauge = Gauge('automl_accuracy', 'Model accuracy', registry=registry)
    run_id_gauge = Gauge('automl_run_id', 'Run ID encoded as int', registry=registry)

    accuracy_gauge.set(accuracy)
    run_id_gauge.set(float(int(run_id[:6], 16)))  # simplify for numeric graph

    push_to_gateway('http://localhost:9091', job='automl_job', registry=registry)
