import mlflow
import mlflow.sklearn

def log_automl_run(run, automl, accuracy):
    best_config = automl.best_config
    mlflow.log_params(best_config)
    mlflow.log_metric("accuracy", accuracy)
    mlflow.sklearn.log_model(automl.model, "model")
