from langchain.chat_models import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
import os

os.environ["OPENAI_API_KEY"] = os.getenv("OPENAI_API_KEY", "sk-<your-key>")

def summarize_run(params, metrics):
    prompt = ChatPromptTemplate.from_template("""
    You are a helpful ML assistant.
    Here is a model performance summary:

    Parameters: {params}
    Metrics: {metrics}

    Summarize the model configuration and its performance in simple terms.
    """)
    messages = prompt.format_messages(params=params, metrics=metrics)
    chat = ChatOpenAI(temperature=0.3)
    response = chat(messages)
    return response.content
