# AutoML + MLflow App

This project combines FLAML-based AutoML, MLflow tracking, Streamlit UI, and LangChain for AI summaries.

## Features
- AutoML with FLAML
- MLflow for model tracking
- Streamlit dashboard
- Natural language summary with LangChain + OpenAI

## Run Instructions
```bash
pip install -r requirements.txt
streamlit run app/streamlit_app.py
```

## DevPod Setup
Supports Devfile for cloud workspaces and CI/CD with GitLab.
