
import streamlit as st
import openai
import pandas as pd
import duckdb

# --- Setup OpenAI Key ---
openai.api_key = st.secrets["OPENAI_API_KEY"] if "OPENAI_API_KEY" in st.secrets else "your-openai-api-key"

# --- Sample DataFrames ---
df_employees = pd.DataFrame({
    "id": [1, 2, 3],
    "name": ["Alice", "Bob", "Charlie"],
    "salary": [50000, 60000, 70000],
    "department_id": [1, 1, 2]
})

df_departments = pd.DataFrame({
    "id": [1, 2],
    "department": ["Engineering", "HR"]
})

# --- DuckDB Setup ---
con = duckdb.connect()
con.register("employees", df_employees)
con.register("departments", df_departments)

# --- Get table schema for prompt ---
def get_schema():
    return (
        "Table: employees (id, name, salary, department_id)\n"
        "Table: departments (id, department)"
    )

# --- Generate SQL from user question ---
def generate_sql(user_question, schema):
    prompt = f"""You are an assistant that writes SQL for DuckDB using Pandas DataFrames. Use the schema to answer the user's question.

Schema:
{schema}

User question: {user_question}
SQL:"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0,
    )
    return response['choices'][0]['message']['content'].strip()

# --- Run SQL query ---
def run_sql(sql):
    try:
        return con.execute(sql).fetchdf()
    except Exception as e:
        return f"SQL Error: {e}"

# --- Generate natural language summary from DataFrame ---
def summarize_result(user_question, df):
    if isinstance(df, str):
        return df  # return error directly

    preview = df.head(10).to_csv(index=False)

    prompt = f"""You are a helpful assistant. The user asked a question about some data, and the result of a SQL query is shown below.

Question: {user_question}

Table Output:
{preview}

Summarize the result in a user-friendly sentence or two:"""

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.5
    )
    return response['choices'][0]['message']['content'].strip()

# --- Streamlit App UI ---
st.title("🧠 Natural Language to SQL with Smart Summary")

if "history" not in st.session_state:
    st.session_state.history = []

user_input = st.text_input("Ask a question about your data:")

if st.button("Submit") and user_input:
    schema = get_schema()
    sql_query = generate_sql(user_input, schema)
    result = run_sql(sql_query)
    summary = summarize_result(user_input, result)

    st.session_state.history.append({
        "question": user_input,
        "sql": sql_query,
        "result": result,
        "summary": summary
    })

# --- Show Result History ---
if st.session_state.history:
    st.subheader("📜 History")
    for i, item in enumerate(reversed(st.session_state.history), 1):
        st.markdown(f"**Q{i}: {item['question']}**")
        st.code(item['sql'], language="sql")
        st.markdown(f"🗣️ Summary: {item['summary']}")
        st.dataframe(item['result'] if isinstance(item['result'], pd.DataFrame) else pd.DataFrame({"Error": [item['result']]}))
