# 🛠️ DevPod Chatbot Generator (VS Code Extension)

This extension creates a `devpod.yaml`, `Dockerfile`, and `requirements.txt` dynamically using a chatbot interface inside VS Code.

## 🚀 Usage

1. Run `npm install`
2. Press `F5` to launch Extension Development Host
3. Open command palette `Ctrl+Shift+P` → "Start DevPod Chatbot"

## 📄 Generates

- `devpod.yaml`
- `Dockerfile`
- `requirements.txt`

Place them in your repo and run with DevPod or DevContainers.
