import * as vscode from 'vscode';
import { runChatbot } from './chatbot';

export function activate(context: vscode.ExtensionContext) {
  const disposable = vscode.commands.registerCommand('devpodChatbot.start', () => {
    runChatbot(context);
  });

  context.subscriptions.push(disposable);
}

export function deactivate() {}
