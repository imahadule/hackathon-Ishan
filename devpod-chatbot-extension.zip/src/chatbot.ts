import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as ejs from 'ejs';

export async function runChatbot(context: vscode.ExtensionContext) {
  const name = await vscode.window.showInputBox({ prompt: 'DevPod name', value: 'ai-devpod' });
  const baseImage = await vscode.window.showInputBox({ prompt: 'Base Docker image', value: 'python:3.11-slim' });
  const pythonPackages = await vscode.window.showInputBox({ prompt: 'Python packages (comma separated)', value: 'pandas,numpy,scikit-learn,mlflow,jupyterlab' });

  const data = {
    name,
    baseImage,
    pythonPackages: pythonPackages?.split(',').map(p => p.trim()) || []
  };

  const templateDir = path.join(context.extensionPath, 'templates');
  const outputDir = vscode.workspace.workspaceFolders?.[0].uri.fsPath || '.';

  const files = ['Dockerfile', 'devpod.yaml', 'requirements.txt'];
  for (const file of files) {
    const content = await ejs.renderFile(path.join(templateDir, file + '.ejs'), data);
    fs.writeFileSync(path.join(outputDir, file), content);
  }

  vscode.window.showInformationMessage('🚀 DevPod files generated!');
}
