import * as vscode from 'vscode';
import { generateMLPipelineCode } from './src/generator';

export function activate(context: vscode.ExtensionContext) {
  let disposable = vscode.commands.registerCommand('autoMLCodeGen.generatePipeline', async () => {
    const input = await vscode.window.showInputBox({ prompt: 'Describe your ML task...' });
    if (!input) return;
    const code = await generateMLPipelineCode(input);
    const newDoc = await vscode.workspace.openTextDocument({ content: code, language: 'python' });
    await vscode.window.showTextDocument(newDoc);
  });

  context.subscriptions.push(disposable);
}

export function deactivate() {}