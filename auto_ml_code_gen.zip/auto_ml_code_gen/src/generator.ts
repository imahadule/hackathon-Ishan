import * as openai from 'openai';

export async function generateMLPipelineCode(prompt: string): Promise<string> {
  // Dummy output for now
  return `# ML Pipeline Code\n# Task: ${prompt}\n\nimport pandas as pd\n# Add ML pipeline logic here`;
}