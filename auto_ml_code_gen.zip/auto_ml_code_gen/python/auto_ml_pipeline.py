"""
Auto-generated ML pipeline based on user input.
Includes AutoML support using FLAML.
"""

import pandas as pd
from flaml import AutoML

def run_automl(file_path, target_column):
    df = pd.read_csv(file_path)
    y = df.pop(target_column)
    X = df

    automl = AutoML()
    automl.fit(X_train=X, y_train=y, task="classification", time_budget=60)

    print("Best ML model:", automl.model)
    print("Best config:", automl.best_config)
    return automl

if __name__ == "__main__":
    model = run_automl("data.csv", "target")
