# Auto ML Code Generator VS Code Extension

Generate end-to-end ML pipelines using natural language in VS Code.
