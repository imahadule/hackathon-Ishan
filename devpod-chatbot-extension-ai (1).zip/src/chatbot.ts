
import * as vscode from 'vscode';
import * as fs from 'fs';
import * as path from 'path';
import * as ejs from 'ejs';
import { Configuration, OpenAIApi } from 'openai';

async function getAIPackages(prompt: string) {
  const configuration = new Configuration({
    apiKey: process.env.OPENAI_API_KEY,
  });
  const openai = new OpenAIApi(configuration);

  const completion = await openai.createChatCompletion({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content: 'You are a DevPod generator assistant. Given a user description, return JSON with keys: base_image, python_packages, system_packages, vscode_extensions.',
      },
      {
        role: 'user',
        content: prompt,
      },
    ],
    temperature: 0.3,
  });

  const response = completion.data.choices[0].message?.content;
  return JSON.parse(response || '{}');
}

export async function runChatbot(context: vscode.ExtensionContext) {
  const prompt = await vscode.window.showInputBox({
    prompt: 'Describe what you are building (e.g., ML app with Flask and dashboards)',
  });

  if (!prompt) {
    vscode.window.showErrorMessage('Prompt is required!');
    return;
  }

  const aiData = await getAIPackages(prompt);
  const name = await vscode.window.showInputBox({ prompt: 'DevPod name', value: 'ai-devpod' });

  const data = {
    name,
    baseImage: aiData.base_image || 'python:3.11-slim',
    pythonPackages: aiData.python_packages || [],
    systemPackages: aiData.system_packages || ['git', 'curl', 'vim'],
    vscodeExtensions: aiData.vscode_extensions || ['ms-python.python', 'ms-toolsai.jupyter'],
  };

  const templateDir = path.join(context.extensionPath, 'templates');
  const outputDir = vscode.workspace.workspaceFolders?.[0].uri.fsPath || '.';

  const files = ['Dockerfile', 'devpod.yaml', 'requirements.txt'];
  for (const file of files) {
    const content = await ejs.renderFile(path.join(templateDir, file + '.ejs'), data);
    fs.writeFileSync(path.join(outputDir, file), content);
  }

  vscode.window.showInformationMessage('🚀 AI-assisted DevPod files generated!');
}
