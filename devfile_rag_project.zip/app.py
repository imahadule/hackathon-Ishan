import streamlit as st
from scripts.generate_devfile import generate_devfile

st.title("Devfile Generator using OpenAI and RAG")
user_input = st.text_area("Describe your development environment requirements:")
if st.button("Generate Devfile"):
    with st.spinner("Generating..."):
        devfile = generate_devfile(user_input)
        st.code(devfile, language='yaml')
