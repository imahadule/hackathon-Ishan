# Devfile RAG Generator

This project generates `devfile.yaml` using OpenAI and RAG from example devfiles.