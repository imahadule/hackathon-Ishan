from langchain.embeddings import HuggingFaceEmbeddings
from langchain.vectorstores import Chroma
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI
from langchain.document_loaders import TextLoader
import os

# Load documents (devfile snippets)
loader = TextLoader("data/python_devfile.txt")
documents = loader.load()

# Create embeddings and vectorstore
embedding = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
db = Chroma.from_documents(documents, embedding)

# Create QA chain with retriever
retriever = db.as_retriever()
llm = OpenAI(temperature=0)
qa_chain = RetrievalQA.from_chain_type(llm=llm, retriever=retriever)

# Example prompt
query = "Create a DevPod for Python with Jupyter, numpy, pandas and VSCode support"
result = qa_chain.run(query)
print(result)
